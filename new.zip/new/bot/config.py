import os


class Config:
    def __init__(self):
        self.vk_token: str = self._get_env('VK_TOKEN', '')
        self.vk_api_version: str = self._get_env('VK_API_VERSION', '5.131')
        self.mongo_uri: str = self._get_env('MONGO_URI', '')
        self.mongo_db: str = self._get_env('MONGO_DB', '')
        self.mongo_collection: str = self._get_env('MONGO_COLLECTION', '')
        self.dgtu_api_token: str = self._get_env('DGTU_API_TOKEN', '')
        self.university_type: str = self._get_env('UNIVERSITY_TYPE', 'T').strip() or 'T'
        self.eios_encryption_key: str = self._get_env('EIOS_ENCRYPTION_KEY', '')
        self.mongo_eios_collection: str = (
            self._get_env('MONGO_EIOS_COLLECTION', '') or 'eios_credentials'
        )

        if not self.vk_token:
            raise ValueError("VK_TOKEN обязателен для работы бота")

    @staticmethod
    def _get_env(key: str, default: str = '') -> str:
        return os.getenv(key, default)
