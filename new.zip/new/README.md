# DGTY Timetable VK Bot

Бот для ВКонтакте для просмотра расписания занятий студентов и преподавателей ДГТУ и ПИ ДГТУ.

## Возможности

- 👥 Выбор и закрепление своей группы при первом запуске
- 📅 Просмотр расписания на сегодня, завтра и неделю
- 🏫 Поддержка двух университетов: ДГТУ и ПИ ДГТУ
- 💾 Хранилище данных на MongoDB

## Требования

- Python 3.8+
- Токен VK-бота (сообщества)
- MongoDB (локально или удаленно)

## Установка

1. Установите зависимости:
```bash
pip install -r requirements.txt
```

2. Установите переменные окружения:
```env
VK_TOKEN=ваш_токен_бота
UNIVERSITY_TYPE=T
MONGO_URI=mongodb://log:pass@ip:port
MONGO_DB=vk
MONGO_COLLECTION=sessions
```

3. Запустите бота:
```bash
python main.py
```

## Переменные окружения

| Переменная | Описание | Обязательна | По умолчанию |
|------------|----------|-------------|--------------|
| `VK_TOKEN` | Токен VK-сообщества | Да | - |
| `UNIVERSITY_TYPE` | `T` — ПИ ДГТУ, `D` — ДГТУ | Нет | `T` |
| `DGTU_API_TOKEN` | Опционально: Bearer-токен, если API начнёт требовать авторизацию для списков | Нет | - |
| `EIOS_ENCRYPTION_KEY` | Ключ Fernet для шифрования логина/пароля ЭИОС в MongoDB (`python -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())"`) | Да, для доп. авторизации | - |
| `MONGO_URI` | URI подключения к MongoDB | Нет | `mongodb://localhost:27017/` |
| `MONGO_DB` | Название базы данных | Нет | `ras` |
| `MONGO_COLLECTION` | Название коллекции сессий | Нет | `sessions` |
| `MONGO_EIOS_COLLECTION` | Коллекция учётных данных ЭИОС (vk_id, eios_id, шифр. логин/пароль) | Нет | `eios_credentials` |

## Структура проекта

```
python_bot/
├── main.py              # Точка входа
├── bot/                 # Основной пакет бота
│   ├── __init__.py
│   ├── vk_bot.py        # Основной класс VK бота
│   ├── vk_handlers.py   # Обработчики команд
│   ├── vk_menu.py       # Меню и кнопки для VK
│   ├── config.py        # Конфигурация
│   ├── constants.py     # Константы
│   ├── utils.py         # Утилиты
│   ├── localizer.py     # Локализация
│   └── api/             # API клиенты
│       ├── __init__.py
│       └── timetable.py # API расписания
├── requirements.txt     # Зависимости
├── Dockerfile          # Docker конфигурация
└── README.md          # Документация
```

## Получение токена VK

1. Создайте сообщество ВКонтакте
2. Перейдите в "Управление" → "Работа с API"
3. Создайте ключ доступа с правами:
   - `messages` - доступ к сообщениям
4. Включите "Возможности" → "Сообщения" → "Разрешить отправку сообщений"
5. Настройте LongPoll для получения событий

## Деплой

### Docker

```bash
docker build -t dgty-vk-bot .
docker run -e VK_TOKEN=ваш_токен -e MONGO_URI=ваш_uri dgty-vk-bot
```

## Лицензия

MIT License
